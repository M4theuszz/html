var botao = document.querySelector("#darkmode");
var texto = document.querySelector("#modo");
var cardBody = document.querySelectorAll(".card-body")
var heartbotao = document.querySelector("#botaoheart")
var heartclass =document.querySelector(".heart")
var contaheart = 0;
var contador = 0;

//botão de like/coração teste
heartbotao.addEventListener("click", function (event){
    event.preventDefault();
    contaheart += 1;
    heartclass.classList.add("heartclasson");
    if(contaheart >= 2){
        heartclass.classList.remove("heartclasson");
        contaheart =0
    }
    console.log(contaheart)
})


//darkmode
botao.addEventListener("click", function (event) {
    event.preventDefault();
    contador += 1;
    body.classList.add("darkmodes");
    imgmodo.classList.add("imgmodoclass");
    tablelightmode.classList.add("tabledarkmode");
    next.classList.add("nexttop");
    cate.classList.add("nexttop");
    modalContent.classList.add("modalcontentdark")
    modo.innerText = "Modo claro";

    for(var correcard = 0; correcard < cardBody.length; correcard++){
        cardall = cardBody[correcard]
        cardall.classList.add("card-body2");
        if (contador >= 2) {
            cardall.classList.remove("card-body2");
        }
    }

    if (contador >= 2) {
        body.classList.remove("darkmodes");
        imgmodo.classList.remove("imgmodoclass");
        tablelightmode.classList.remove("tabledarkmode");
        next.classList.remove("nexttop");
        cate.classList.remove("nexttop");
        modo.innerText = "Modo escuro";
        modalContent.classList.remove("modalcontentdark")
        contador = 0;
    }
    console.log("fui clicado");
    
})
