//datas
var data = new Date();
var ano = data.getFullYear();
var anostr = ano.toString();
var mesdata = data.getMonth();//mes numero
var dian = data.getDate();//dia numero
var diastr = dian.toString();//dia convertido para string
var sd = data.getDay();//dia da semana numero

var diateste = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
var diasemana = ["Domingo","Segunda", "Terça", "Quarta", "Quinta", "Sexta","Sabado", "Domingo","Segunda", "Terça", "Quarta", "Quinta", "Sexta","Sabado"];//dias string
var mes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

//inserirnohtml
anoclasses = document.querySelectorAll(".anoatual");
for (i = 0; i < anoclasses.length; i++) {
    anoclasses[i].textContent = anostr;
}
document.querySelectorAll("#mesatual");
mesatual.textContent = mes[mesdata];

document.querySelectorAll("#diaatual");
diaatual.textContent = diateste[dian];

document.querySelectorAll("#diadasemananow");
diadasemananow.textContent = diasemana[sd];

document.querySelectorAll("#diaM1");
diaM1.textContent = diateste[dian + 1];

document.querySelectorAll("#diaSM1");
diaSM1.textContent = diasemana[sd + 1];

document.querySelectorAll("#diaM2");
diaM2.textContent = diateste[dian + 2] ;

document.querySelectorAll("#diaSM2");
diaSM2.textContent = diasemana[sd + 2];

document.querySelectorAll("#diaM3");
diaM3.textContent = diateste[dian + 3];

document.querySelectorAll("#diaSM3");
diaSM3.textContent = diasemana[sd + 3];

document.querySelectorAll("#diaM4");
diaM4.textContent = diateste[dian + 4] ;

document.querySelectorAll("#diaSM4");
diaSM4.textContent = diasemana[sd + 4];

document.querySelectorAll("#diaM5");
diaM5.textContent = diateste[dian + 5];

document.querySelectorAll("#diaSM5");
diaSM5.textContent = diasemana[sd + 5];

document.querySelectorAll("#diaM6");
diaM6.textContent = diateste[dian + 6];

document.querySelectorAll("#diaSM6");
diaSM6.textContent = diasemana[sd + 6];

//functions e etc
var temEventoDia = document.querySelector("#temEventoDia");
console.log(temEventoDia.innerHTML);

var eventonocalendario = document.querySelector(".diadoevento");
console.log(eventonocalendario);

for (var corredor = 0; corredor < diateste.length; corredor++){
     if(temEventoDia.innerHTML == diateste[corredor]){
        eventonocalendario[corredor].classList.add("dianocalendario")
        
    }; 
}

//checker

    




