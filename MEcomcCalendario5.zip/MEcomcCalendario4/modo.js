var botao = document.querySelector("#darkmode");
var texto = document.querySelector("#modo");
var cardBody = document.querySelectorAll(".card-body")
var contador = 0;

botao.addEventListener("click", function (event) {
    event.preventDefault();
    contador += 1;
    body.classList.add("darkmodes");
    imgmodo.classList.add("imgmodoclass");
    tablelightmode.classList.add("tabledarkmode");
    next.classList.add("nexttop");
    cate.classList.add("nexttop");
    modo.innerText = "Modo claro";

    for(var correcard = 0; correcard < cardBody.length; correcard++){
        cardall = cardBody[correcard]
        cardall.classList.add("card-body2");
        if (contador >= 2) {
            cardall.classList.remove("card-body2");
        }
        console.log(cardall)

    }

    if (contador >= 2) {
        body.classList.remove("darkmodes");
        imgmodo.classList.remove("imgmodoclass");
        tablelightmode.classList.remove("tabledarkmode");
        next.classList.remove("nexttop");
        cate.classList.remove("nexttop");
        modo.innerText = "Modo escuro";
        contador = 0;
    }
    console.log("fui clicado");
    
})
