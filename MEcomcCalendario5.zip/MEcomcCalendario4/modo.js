var botao = document.querySelector("#darkmode");
var texto = document.querySelector("#modo");
var contador = 0;

botao.addEventListener("click", function (event) {
    event.preventDefault();
    contador += 1;
    body.classList.add("darkmodes");
    imgmodo.classList.add("imgmodoclass");
    tablelightmode.classList.add("tabledarkmode");
    modo.innerText = "Modo claro";
    if (contador >= 2) {
        body.classList.remove("darkmodes");
        imgmodo.classList.remove("imgmodoclass")
        tablelightmode.classList.remove("tabledarkmode")
        modo.innerText = "Modo escuro";
        contador = 0;
    }
    console.log("fui clicado");
})
