//datas
var data = new Date();
var ano = data.getFullYear();
var anostr = ano.toString();
var mesdata = data.getMonth();//mes numero
var dian = data.getDate();//dia numero
var diastr = dian.toString();//dia convertido para string
var sd = data.getDay();//dia da semana numero
console.log(mesdata)
var diateste = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
var diasemana = ["Domingo","Segunda", "Terça", "Quarta", "Quinta", "Sexta","Sabado", "Domingo","Segunda", "Terça", "Quarta", "Quinta", "Sexta","Sabado"];//dias string
var mes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
var cardimport = document.querySelectorAll(".card")
var cardevento = document.querySelectorAll("#cardaqui")

//inserirnohtml
anoclasses = document.querySelectorAll(".anoatual");
for (i = 0; i < anoclasses.length; i++) {
    anoclasses[i].textContent = anostr;
}
//dias no calendario queryselector
{
    document.querySelectorAll("#mesatual");
    mesatual.textContent = mes[mesdata];

    document.querySelectorAll("#diaatual");
    diaatual.textContent = diateste[dian];

    document.querySelectorAll("#diadasemananow");
    diadasemananow.textContent = diasemana[sd];

    document.querySelectorAll("#diaM1");
    diaM1.textContent = diateste[dian + 1];

    document.querySelectorAll("#diaSM1");
    diaSM1.textContent = diasemana[sd + 1];

    document.querySelectorAll("#diaM2");
    diaM2.textContent = diateste[dian + 2];

    document.querySelectorAll("#diaSM2");
    diaSM2.textContent = diasemana[sd + 2];

    document.querySelectorAll("#diaM3");
    diaM3.textContent = diateste[dian + 3];

    document.querySelectorAll("#diaSM3");
    diaSM3.textContent = diasemana[sd + 3];

    document.querySelectorAll("#diaM4");
    diaM4.textContent = diateste[dian + 4];

    document.querySelectorAll("#diaSM4");
    diaSM4.textContent = diasemana[sd + 4];

    document.querySelectorAll("#diaM5");
    diaM5.textContent = diateste[dian + 5];

    document.querySelectorAll("#diaSM5");
    diaSM5.textContent = diasemana[sd + 5];

    document.querySelectorAll("#diaM6");
    diaM6.textContent = diateste[dian + 6];

    document.querySelectorAll("#diaSM6");
    diaSM6.textContent = diasemana[sd + 6];
}
//semanas no calendario queryselector
{
    var sdm1 = document.querySelector("#diaSM1");
    var sdm2 = document.querySelector("#diaSM2");
    var sdm3 = document.querySelector("#diaSM3");
    var sdm4 = document.querySelector("#diaSM4");
    var sdm5 = document.querySelector("#diaSM5");
    var sdm6 = document.querySelector("#diaSM6");
}
//busca dias e eventos no html
{
var eventonocalendario = document.querySelectorAll(".diadoevento");
console.log(eventonocalendario);
var diahoje = document.querySelector("#diaatual");
var dia1 = document.querySelector("#diaM1");
var dia2 = document.querySelector("#diaM2");
var dia3 = document.querySelector("#diaM3");
var dia4 = document.querySelector("#diaM4");
var dia5 = document.querySelector("#diaM5");
var dia6 = document.querySelector("#diaM6");
var diasemananhtml = document.querySelectorAll(".tabledata > p");

var temEventoDia = document.querySelectorAll("#temEventoDia");
}
//for do calendario
{
    for (x = 0; x < temEventoDia.length; x++) {
        var eventos = temEventoDia[x].innerHTML;
        var semanas = diasemananhtml[x].innerHTML;
        console.log(eventos)
        console.log(semanas)
        //se o dia do evento for igual dia da semana apresentado no calendario, botar class dando destaque para o dia.
        if (eventos == diahoje.innerHTML) {
            diahoje.classList.add("dianocalendario")
        } else if (eventos == dia1.innerHTML) {
            dia1.classList.add("dianocalendario")
        } else if (eventos == dia2.innerHTML) {
            dia2.classList.add("dianocalendario");
        } else if (eventos == dia3.innerHTML) {
            dia3.classList.add("dianocalendario");
        } else if (eventos == dia4.innerHTML) {
            dia4.classList.add("dianocalendario");
        } else if (eventos == dia5.innerHTML) {
            dia5.classList.add("dianocalendario");
        } else if (eventos == dia6.innerHTML) {
            dia6.classList.add("dianocalendario");
        }/*else if(diateste[dian]){
            sdm1.classList.add("semanaremove");
            sdm2.classList.add("semanaremove");
            sdm3.classList.add("semanaremove");
            sdm4.classList.add("semanaremove");
            sdm5.classList.add("semanaremove");
            sdm6.classList.add("semanaremove");
        }*/
    }
}

