var botaonext =document.querySelector("#botaonext");
var botaoprev =document.querySelector("#botaoprev");

var cliquenext = 0;
var cliqueprev = 0;

botaonext.addEventListener("click", function(event){
    event.preventDefault();
    cliquenext += 1;
    console.log("nextcliques")
    var passames = mes[mesdata += 1]
    console.log(passames)

})