//functions
function next(){  
    var botao = document.querySelector("#botaonext");

    botao.addEventListener("click", function(event){
    event.preventDefault();
    var mes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    var mesdata = data.getMonth();
    for(var mesi = mesdata; mesi < mes.length; mesi++){
        
        console.log(mesi)
    }
});
};

//datas
var data = new Date();
var ano = data.getFullYear();
var mesdata = data.getMonth();//mes numero
var dian = data.getDate();//dia numero
var diastr = dian.toString();//dia convertido para string
var sd = data.getDay();//dia da semana numero

var diasemana = ["Domingo","Segunda", "Terça", "Quarta", "Quinta", "Sexta","Sabado"];//dias string
var mes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];


//inserirnohtml
document.querySelector("#anoatual");
anoatual.textContent = ano;

document.querySelectorAll("#mesatual");
mesatual.textContent = mes[mesdata];

document.querySelectorAll("#diaatual");
diaatual.textContent = diastr;

document.querySelectorAll("#diadasemananow");
diadasemananow.textContent = diasemana[sd];


//for de 31 ou 30

    

